"""Store the version info so that setup.py and __init__ can access it. """
__version__ = "1.7.0"
